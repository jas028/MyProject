package budgetmanager.util;

public enum IncomeCategory {
	GENERAL
}
