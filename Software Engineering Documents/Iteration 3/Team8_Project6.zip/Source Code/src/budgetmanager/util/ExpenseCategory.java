package budgetmanager.util;

public enum ExpenseCategory {
	MISCELLANEOUS,
	HOUSING,
	BILL,
	FOOD,
	RECREATION,
	SAVINGS
}
